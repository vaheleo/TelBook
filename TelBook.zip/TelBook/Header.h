/*
 * Header.h
 *
 *  Created on: Jun 6, 2017
 *      Author: Vahe
 */

#ifndef HEADER_H_
#define HEADER_H_

#include<iostream>
#include<iomanip>
#include<string>
#include <fstream>
using namespace std;


#endif /* HEADER_H_ */
